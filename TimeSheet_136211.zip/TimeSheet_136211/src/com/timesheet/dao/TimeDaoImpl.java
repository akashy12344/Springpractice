package com.timesheet.dao;

import java.util.List;

import javax.persistence.EntityManager;



import javax.persistence.TypedQuery;




import com.timesheet.dto.TimeSheet;

public class TimeDaoImpl implements TimeDao {

	

	private EntityManager entityManager;

	public TimeDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public void addDetails(TimeSheet time) {
		
		entityManager.getTransaction().begin();
		entityManager.persist(time);
		entityManager.flush();
		entityManager.getTransaction().commit();
		
		return;
	}





	@Override
	public List<TimeSheet> getTimeDetails(String id){
		List<TimeSheet> acc=null;
		String qStr = "SELECT e FROM TimeSheet e WHERE e.empid='"+id+"'";
		TypedQuery<TimeSheet> query = entityManager.createQuery(qStr, TimeSheet.class);
		//query.setParameter("pempid", id);
		
		 acc = query.getResultList();
		 System.out.println(acc);
		
		return acc;
		
	}
	
	@Override
	public List<TimeSheet> listAllEmployees()
	{
		List<TimeSheet> acc=null;
		String qStr = "SELECT e FROM TimeSheet e ";
		TypedQuery<TimeSheet> query = entityManager.createQuery(qStr, TimeSheet.class);
		//query.setParameter("pempid", id);
		
		 acc = query.getResultList();
		 System.out.println(acc);
		
		return acc;
	}
}
