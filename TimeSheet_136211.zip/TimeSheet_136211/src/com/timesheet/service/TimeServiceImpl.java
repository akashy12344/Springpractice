package com.timesheet.service;

import java.util.List;

import com.timesheet.dao.TimeDao;
import com.timesheet.dao.TimeDaoImpl;
import com.timesheet.dto.TimeSheet;


public class TimeServiceImpl implements TimeService {

	
	TimeDao dao;
	
	public TimeServiceImpl()
	{
		dao=new TimeDaoImpl();
	}
	@Override
	public void addDetails(TimeSheet time) {
		
	dao.addDetails(time);
	return;

	}


	@Override
	public List<TimeSheet> getTimeDetails(String id) {
		
		return dao.getTimeDetails(id);
	}
	@Override
	public List<TimeSheet> listAllEmployees() {
		
		return dao.listAllEmployees();
	}
	

}
