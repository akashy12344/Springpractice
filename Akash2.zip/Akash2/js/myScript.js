function myFunction() {
   document.getElementById("dem") = "https://www.w3schools.com";
}